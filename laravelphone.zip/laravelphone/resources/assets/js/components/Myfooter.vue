<template>
	
<footer class="footer">
  <div class="container">
    <div class="content has-text-centered">
      <p>
        <strong>Phonebook App</strong> by <a href="http://nayeemriddhi.net">Nayeem Hyder</a>
      </p>
    </div>
  </div>
</footer>



	
</template>