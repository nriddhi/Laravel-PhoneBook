<template>
	


  <section class="section">
    <div class="container">
      <h1 class="title">Section</h1>
      <h2 class="subtitle" style="margin-top:10px">
        This is about page
      </h2>
    </div>
  </section>







</template>